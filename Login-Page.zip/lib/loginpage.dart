// ignore_for_file: prefer_const_constructors

import 'package:flutter/material.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({Key? key}) : super(key: key);

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Center(
          child: Text("Login Page",
              style: TextStyle(
                fontSize: 25,
                fontWeight: FontWeight.w600,
              )),
        ),
      ),
      body: Column(
        children: [
          SizedBox(
            height: 20,
          ),
          Center(
              child: CircleAvatar(
            radius: 100,
            backgroundColor: Colors.green,
            child: CircleAvatar(
              radius: 95,
              backgroundImage: AssetImage('Images/my-pic1.png'),
            ),
          )),
          SizedBox(
            height: 10,
          ),
          Padding(
            padding: EdgeInsets.all(15),
            child: TextField(
              decoration: InputDecoration(
                border: OutlineInputBorder(),
                labelText: 'Email Address',
                hintText: 'Enter Email Address',
              ),
            ),
          ),
          SizedBox(
            height: 5,
          ),
          Padding(
            padding: EdgeInsets.all(15),
            child: TextField(
              obscureText: true,
              decoration: InputDecoration(
                border: OutlineInputBorder(),
                labelText: 'Password',
                hintText: 'Enter Password',
              ),
            ),
          ),
          SizedBox(
            height: 10,
          ),
          Container(
              width: 170,
              height: 50,
              color: Colors.green,
              child: ElevatedButton(
                  onPressed: () {},
                  child: Text("LOGIN NOW",
                      style: TextStyle(
                          fontSize: 20, fontWeight: FontWeight.w500)))),
        ],
      ),
    );
  }
}
